import { configureStore } from "@reduxjs/toolkit";

export const store = configureStore({
    reducer: {

    },

    middleware: (getDefaultMiddleware) => ({
        serializableCheck: false
    })
});


export default store;