export const WEBSITESEARCH = [
    { label: 'Yes' },
{ label: 'No' },

      
    ];
    