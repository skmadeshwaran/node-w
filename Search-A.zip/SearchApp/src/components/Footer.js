import React, {useEffect, useState} from "react";
import '../styles/footer.css'

const Footer = () => {
    return (
      <div className="container">
          <p>© 2023 ABC Corporation. All rights reserved.</p>
      </div>
    );
  }
  
  export default Footer;
  