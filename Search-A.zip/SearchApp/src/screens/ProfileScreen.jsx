import React, {useEffect, useState} from "react";
const Profile=()=> {
    return (
     /* <div className="App">
          <p>Profile screen</p>
      </div>*/<></>
    );
  }
  
  export default Profile;
  