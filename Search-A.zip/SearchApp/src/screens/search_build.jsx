import React, { useEffect, useState, useRef } from "react";
import Header from "../components/header";
import '../styles/searchBuild.css';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box'
import Button from '@mui/material/Button';
import PersonSearchRoundedIcon from '@mui/icons-material/PersonSearchRounded';
import { METROAREA } from '../mock-data/metroarea-data';
import { SICCODE } from '../mock-data/siccode-data';
import { NAICSCODE } from '../mock-data/naicscode-data';
import { WEBSITESEARCH } from '../mock-data/websitesearch-data';
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';
import { useLocation, useNavigate } from "react-router";
import Result from "./Result";
import { Controller, useForm } from "react-hook-form";
import axios from 'axios';
import Switch from '@mui/material/Switch';
import FormControlLabel from '@mui/material/FormControlLabel';


/*
 TODO: 
 formGroupSearch: {
  contactLevel: {
    title: ''
  }

  locations: {

  }

 }
*/
const SearchBuild = (props) => {
  const [selectedMenu, setSelectedMenu] = useState('showAll');
  const [tableView, setTableView] = useState(false);
  const [rows, setRows] = useState([]);
  console.log(JSON.stringify(props))
  const { control, getValues, register, sub, setValue } = useForm({
    mode: 'onBlur',
    defaultValues: {
      contact: {
        contacttitle: '',
        contactlevel: []
      },
      country: {
        companycountry: [],
        companystate: [],
        companycity: [],
        companyzipcode: [],
        metroarea: [],
        companycounty: []
      },
      company: {
        CompanyemployeesFrom: '',
        CompanyemployeesTo: '',
        CompanyRevenueFrom: '',
        CompanyRevenueTo: '',

      },
      industry: {
        siccode: [],
        naicscode: [],

      },
      additional: {
        company_search: '',
        website_search: [],
      }
    }
  })
  if (props && props.controls && props.controls._formValues && props.controls._formValues.contact && props.controls._formValues.contact.contactlevel) {

    console.log(props.controls._formValues.contact.contactlevel[0]);
  }
  const [selectedFilters, setSelectedFilters] = useState({
    contact: {
      contactlevel: [],
      contacttitle: '',
    },
    country: {
      companycountry: [],
      companystate: [],
      companycity: [],
      companyzipcode: [],
      metroarea: [],
      companycounty: [],
    },
    company: {
      CompanyemployeesFrom: '',
      CompanyemployeesTo: '',
      CompanyRevenueFrom: '',
      CompanyRevenueTo: ''
    },
    industry: {
      siccode: [],
      naicscode: [],
    },
    additional: {
      company_search: '',
      website_search: '',
    },
  });

  const [prevFormData, setPrevFormData] = useState({
    contact: {
      contactlevel: [],
      contacttitle: '',
    },
    country: {
      companycountry: [],
      companystate: [],
      companycity: [],
      companyzipcode: [],
      metroarea: [],
      companycounty: [],
    },
    company: {
      CompanyemployeesFrom: '',
      CompanyemployeesTo: '',
      CompanyRevenueFrom: '',
      CompanyRevenueTo: ''
    },
    industry: {
      siccode: '',
      naicscode: '',
    },
    additional: {
      company_search: '',
      website_search: '',
    },
  });

  // useEffect(() => {

    
  // },[]);

  const handleClearAll = () => {
    setSelectedFilters({
      contact: {
        contactlevel: [],
        contacttitle: '',
      },
      country: {
        companycountry: [],
        companystate: [],
        companycity: [],
        companyzipcode: [],
        metroarea: [],
        companycounty: [],
      },
      company: {
        Companyemployees: '',
        CompanyRevenue: '',
      },
      industry: {
        siccode: [],
        naicscode: [],
      },
      additional: {
        company_search: '',
        website_search: '',
      },
    });
  };


  const filterOptions = (object) => {
    let val = [];
    for (let obj in object) {
      if (object.hasOwnProperty(obj)) {
        if (!!object[obj] && typeof object[obj] === 'string') {
          val.push(`${obj}=${object[obj]}`)
        } else if (!!object[obj] && Array.isArray(object[obj])) {
          if (object[obj].length > 0) {
            val.push(`${obj}=${object[obj].join('|')}`)
          }
        }
      }
    }
    return val.join(',')
  }
  const selectedMenuClick = (selectedMenuName) => {
    setSelectedMenu(selectedMenuName);

  }
  const { state } = useLocation();
  const navigate = useNavigate();
  // selectedMenuClick(state)


  const clickViewBtn = () => {
    let conditions = []
    const filters = getValues();
    for (let obj in filters) {
      console.log(filters[obj])
      const contact = filterOptions(filters[obj]);
      console.log(!!contact)
      if (!!contact) {
        conditions.push(contact)
      }
    }
    axios.post('/getdata', {
      conditions: conditions.join(',')
    }).then(data => {
      console.log(data.data.data);
      if (data.data.data) {
        setRows(data.data.data)
      }

    })
      .catch(error => {
        setRows([]);
        console.log('####', error)
      })
    setTableView(true);
  }

  const setResult = () => {
    let conditions = []
    const filters = getValues();
    for (let obj in filters) {
      const contact = filterOptions(filters[obj]);
      if (!!contact) {
        conditions.push(contact)
      }
    }

    axios.post('/getdata', {
      conditions: conditions.join(',')
    }).then(data => {
      if (data.data.data) {
        setCount(data.data.count)
      } else {
        setCount(0)
      }

    })
      .catch(error => {
        console.log('####', error)
      })
  }

  useEffect(() => {
    initCalls();
  }, []);

  useEffect(() => {

    if (state) {
      setSelectedMenu(state.name)
      navigate('/searchs', {})
    }

  }, [selectedMenu, state, navigate])

  const [isOpen, setIsOpen] = useState(false);
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [contactOptionsData, setContactOptionsData] = useState([]);
  const [cityOptionsData, setCityOptionsData] = useState([]);
  const [countriesOptionsData, setCountriesOptionsData] = useState([]);
  const [countryOptionsData, setCountryOptionsData] = useState([]);
  const [statesOptionsData, setStatesOptionsData] = useState([]);
  const [zipcodeOptionsData, setZipcodeOptionsData] = useState([]);

  const initCalls = async () => {
    try {
      const response = await axios.get('/formdata');
      setContactOptionsData(await setLabelFormat(response.data.contactlevels.sort()));
      setCityOptionsData(await setLabelFormat(response.data.city.sort()));
      setCountriesOptionsData(await setLabelFormat(response.data.countries.sort()));
      setCountryOptionsData(await setLabelFormat(response.data.county.sort()));
      setStatesOptionsData(await setLabelFormat(response.data.states.sort()));
      setZipcodeOptionsData(await setLabelFormat(response.data.zipcodes.sort()));

      if (props.controls && props.controls._formValues) {
        let contact_arr = [];
       //"companystate":"","companycity":"","companyzipcode":"","metroarea":[],"companycounty":""},"company":{"Companyemployees":"","CompanyRevenue":"","Companyrevenue":"","Company_search":""},"industry":{"siccode":"","naicscode":""},"additional":{"company_search":"","website_search":""},"industy":{}}
        let _form = props.controls._formValues;
        setDefaultContact(setLabelForm(_form.contact.contactlevel));
        setValue('contact.contactlevel', _form.contact.contactlevel);

        
        setDefaultCountry(setLabelForm(_form.country.companycountry));
        setValue('company.companycountry', _form.country.companycountry);

        setDefaultState(setLabelForm(_form.country.companystate));
        setValue('country.companystate', _form.country.companystate);

        setDefaultCity(setLabelForm(_form.country.companycity));
        setValue('country.companycity', _form.country.companycity);

        setDefaultZip(setLabelForm(_form.country.companyzipcode));
        setValue('country.companyzipcode', _form.country.companyzipcode);

        setDefaultMetro(setLabelForm(_form.country.metroarea));
        setValue('country.metroarea', _form.country.metroarea);

        setDefaultCounty(setLabelForm(_form.country.companycounty));
        setValue('country.companycounty', _form.country.companycounty);

        setDefaultSIC(setLabelForm(_form.industry.siccode));
        setValue('industry.siccode', _form.industry.siccode);

        setDefaultNAICS(setLabelForm(_form.industry.naicscode));
        setValue('industry.naicscode', _form.industry.naicscode);
        
        setDefaultWebSiteSearch(setLabelForm(_form.additional.website_search));
        setValue('additional.website_search', _form.additional.website_search);

        setValue('contact.contacttitle', _form.contact.contacttitle);
        setValue('company.CompanyemployeesFrom', _form.company.CompanyemployeesFrom);
        setValue('company.CompanyemployeesTo', _form.company.CompanyemployeesTo);
        setValue('company.CompanyRevenueFrom', _form.company.CompanyRevenueFrom);
        setValue('company.CompanyRevenueTo', _form.company.CompanyRevenueTo);
        setValue('additional.Company_search', _form.additional.Company_search);
        
        setResult();
      }

    } catch (e) {

    }
  }

  const setLabelFormat = async (arrayData) => {
    const convertArray = arrayData.map((item) => ({
      label: item
    }));
    return convertArray;
  }

  const setLabelForm = (arrayData) => {
    const convertArray = arrayData.map((item) => ({
      label: item
    }));
    return convertArray;
  }

  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  const handleCheckboxChange = (option) => {
    if (selectedOptions.includes(option)) {
      setSelectedOptions(selectedOptions.filter(item => item !== option));
    } else {
      setSelectedOptions([...selectedOptions, option]);
    }
  };

  const [count, setCount] = useState(0);

  const handleResultClick = () => {

    const newCount = 10;
    setCount(newCount);
  };

  const [isContactChecked, setContactChecked] = useState(false);
  const [isTitleChecked,setTitleChecked] = useState(false);
  const [isCountryChecked,setCountryChecked] = useState(false);
  const [isStateChecked,setStateChecked] = useState(false);
  const [isCityChecked,setCityChecked] = useState(false);
  const [isZipChecked,setZipChecked] = useState(false);
  const [isMetroChecked,setMetroChecked] = useState(false);
  const [isCompanyCountryChecked,setCompanyCountryChecked] = useState(false);
  const [isEsizeFromChecked,setEsizeChecked] = useState(false);
  const [isEsizeToChecked,setEsizeToChecked] = useState(false);
  const [isRsizeFromChecked,setRsizeFromChecked] = useState(false);
  const [isRsizeToChecked,setRsizeToChecked] = useState(false);
  const [isSICChecked,setSICChecked] = useState(false);
  const [isCompanyChecked,setCompanyChecked] = useState(false);
  const [isNAICSChecked,setNAICSChecked] = useState(false);
  const [isWebsiteChecked,setWebsiteChecked] = useState(false);

  const [defaultContact, setDefaultContact] = useState([]);
  const [defaultCountry, setDefaultCountry] = useState([]);
  const [defaultState, setDefaultState] = useState([]);
  const [defaultCity, setDefaultCity] = useState([]);
  const [defaultZip, setDefaultZip] = useState([]);
  const [defaultMetro, setDefaultMetro] = useState([]);
  const [defaultCounty, setDefaultCounty] = useState([]);
  const [defaultSIC, setDefaultSIC] = useState([]);
  const [defaultNAICS, setDefaultNAICS] = useState([]);
  const [defaultWebSiteSearch, setDefaultWebSiteSearch] = useState([]);
  
  const refContactLevel = useRef(null);
  
  const handleExcludeChange = (name,e) => {
    const formData = getValues();    
    if (name == 'contact') {
      if (isContactChecked) {
        setValue('contact.contactlevel', prevFormData.contact.contactlevel);
        setResult();
        setContactChecked(false);
      } else {
        const selectedContact = formData.contact.contactlevel;
        setPrevFormData((prevState) => ({
          ...prevState,
          contact: {
            ...prevState.contact, 
            contactlevel: selectedContact,
          },
        }));
        setValue('contact.contactlevel', []);
        setResult();
        setContactChecked(true);
      }
    }

    if (name == 'title') {
      if (isTitleChecked) {
        setValue('contact.contacttitle', prevFormData.contact.contacttitle);
        setResult();
        setTitleChecked(false);
      } else {
        const selectedTitle = formData.contact.contacttitle;
        setPrevFormData((prevState) => ({
          ...prevState,
          contact: {
            ...prevState.contact, 
            contacttitle: selectedTitle,
          },
        }));
        setValue('contact.contacttitle', '');
        setResult();
        setTitleChecked(true);
      }
    }

    if (name == 'country') {
      if (isCountryChecked) {
        setValue('country.companycountry', prevFormData.country.companycountry);
        setResult();
        setCountryChecked(false);
      } else {
        const prev = formData.country.companycountry;
        setPrevFormData((prevState) => ({
          ...prevState,
          country: {
            ...prevState.country, 
            companycountry: prev,
          },
        }));
        setValue('country.companycountry', []);
        setResult();
        setCountryChecked(true);
      }
    }

    if (name == 'state') {
      if (isStateChecked) {
        setValue('country.companystate', prevFormData.country.companystate);
        setResult();
        setStateChecked(false);
      } else {
        const prev = formData.country.companystate;
        setPrevFormData((prevState) => ({
          ...prevState,
          country: {
            ...prevState.country, 
            companystate: prev,
          },
        }));
        setValue('country.companystate', []);
        setResult();
        setStateChecked(true);
      }
    }

    if (name == 'city') {
      if (isCityChecked) {
        setValue('country.companycity', prevFormData.country.companycity);
        setResult();
        setCityChecked(false);
      } else {
        const prev = formData.country.companycity;
        setPrevFormData((prevState) => ({
          ...prevState,
          country: {
            ...prevState.country, 
            companycity: prev,
          },
        }));
        setValue('country.companycity', []);
        setResult();
        setCityChecked(true);
      }
    }

    if (name == 'zip') {
      if (isZipChecked) {
        setValue('country.companyzipcode', prevFormData.country.companyzipcode);
        setResult();
        setZipChecked(false);
      } else {
        const prev = formData.country.companyzipcode;
        setPrevFormData((prevState) => ({
          ...prevState,
          country: {
            ...prevState.country, 
            companyzipcode: prev,
          },
        }));
        setValue('country.companyzipcode', []);
        setResult();
        setZipChecked(true);
      }
    }

    if (name == 'metro') {
      if (isMetroChecked) {
        setValue('country.metroarea', prevFormData.country.metroarea);
        setResult();
        setMetroChecked(false);
      } else {
        const prev = formData.country.metroarea;
        setPrevFormData((prevState) => ({
          ...prevState,
          country: {
            ...prevState.country, 
            metroarea: prev,
          },
        }));
        setValue('country.metroarea', []);
        setResult();
        setMetroChecked(true);
      }
    }

    if (name == 'companycountry') {
      if (isCompanyCountryChecked) {
        setValue('country.companycounty', prevFormData.country.companycounty);
        setResult();
        setCompanyCountryChecked(false);
      } else {
        const prev = formData.country.companycounty;
        setPrevFormData((prevState) => ({
          ...prevState,
          country: {
            ...prevState.country, 
            companycounty: prev,
          },
        }));
        setValue('country.companycounty', []);
        setResult();
        setCompanyCountryChecked(true);
      }
    }
    
    if(name=='employeesizefrom'){
      if (isEsizeFromChecked) {
        setValue('company.CompanyemployeesFrom', prevFormData.company.CompanyemployeesFrom);
        setResult();
        setEsizeChecked(false);
      } else {
        const prev = formData.company.CompanyemployeesFrom;
        setPrevFormData((prevState) => ({
          ...prevState,
          company: {
            ...prevState.company, 
            CompanyemployeesFrom: prev,
          },
        }));
        setValue('company.CompanyemployeesFrom', '');
        setResult();
        setEsizeChecked(true);
      }
    }

    if(name=='employeesizeto'){
      if (isEsizeToChecked) {
        setValue('company.CompanyemployeesTo', prevFormData.company.CompanyemployeesTo);
        setResult();
        setEsizeToChecked(false);
      } else {
        const prev = formData.company.CompanyemployeesTo;
        setPrevFormData((prevState) => ({
          ...prevState,
          company: {
            ...prevState.company, 
            CompanyemployeesTo: prev,
          },
        }));
        setValue('company.CompanyemployeesTo', []);
        setResult();
        setEsizeToChecked(true);
      }
    }

    if(name=='revenuesizefrom'){
      if (isRsizeFromChecked) {
        setValue('company.CompanyRevenue', prevFormData.company.CompanyRevenue);
        setResult();
        setRsizeFromChecked(false);
      } else {
        const prev = formData.company.CompanyRevenue;
        setPrevFormData((prevState) => ({
          ...prevState,
          company: {
            ...prevState.company, 
            CompanyRevenue: prev,
          },
        }));
        setValue('company.CompanyRevenue', []);
        setResult();
        setRsizeFromChecked(true);
      }
    }

    if(name=='revenuesizeto'){
      if (isRsizeToChecked) {
        setValue('company.CompanyRevenue', prevFormData.company.CompanyRevenue);
        setResult();
        setRsizeToChecked(false);
      } else {
        const prev = formData.company.CompanyRevenue;
        setPrevFormData((prevState) => ({
          ...prevState,
          company: {
            ...prevState.company, 
            CompanyRevenue: prev,
          },
        }));
        setValue('company.CompanyRevenue', []);
        setResult();
        setRsizeToChecked(true);
      }
    }

    if(name=='sic'){
      if (isSICChecked) {
        setValue('industry.siccode', prevFormData.industry.siccode);
        setResult();
        setSICChecked(false);
      } else {
        const prev = formData.industry.siccode;
        setPrevFormData((prevState) => ({
          ...prevState,
          industry: {
            ...prevState.industry, 
            siccode: prev,
          },
        }));
        setValue('industry.siccode', '');
        setResult();
        setSICChecked(true);
      }
    }

    if(name=='naics'){
      if (isNAICSChecked) {
        setValue('industry.naicscode', prevFormData.industry.naicscode);
        setResult();
        setNAICSChecked(false);
      } else {
        const prev = formData.industry.naicscode;
        setPrevFormData((prevState) => ({
          ...prevState,
          industry: {
            ...prevState.industry, 
            naicscode: prev,
          },
        }));
        setValue('industry.naicscode', '');
        setResult();
        setNAICSChecked(true);
      }
    }

    if(name=='companysearch'){
      if (isCompanyChecked) {
        setValue('additional.Company_search', prevFormData.additional.company_search);
        setResult();
        setCompanyChecked(false);
      } else {
        const prev = formData.additional.company_search;
        setPrevFormData((prevState) => ({
          ...prevState,
          additional: {
            ...prevState.additional, 
            company_search: prev,
          },
        }));
        setValue('additional.Company_search', '');
        setResult();
        setCompanyChecked(true);
      }
    }


    if(name=='websitesearch'){
      if (isWebsiteChecked) {
        setValue('additional.website_search', prevFormData.additional.website_search);
        setResult();
        setWebsiteChecked(false);
      } else {
        const prev = formData.additional.website_search;
        setPrevFormData((prevState) => ({
          ...prevState,
          additional: {
            ...prevState.additional, 
            website_search: prev,
          },
        }));
        setValue('additional.website_search', '');
        setResult();
        setWebsiteChecked(true);
      }
    }


  }

  const handleTitleKeyPress = (e) => {
    setValue('contact.contacttitle', e.target.value);
    setResult();
  };


  //From data API Connection 

  const [formData, setFormData] = useState({}); // State to hold form data
  const [error, setError] = useState(null);

  // Function to handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('/formdata', formData);
      console.log('API response:', response.data);

      // Optionally, you can handle success here, e.g., show a success message.
    } catch (err) {
      console.error('API error:', err);

      // Handle API error, e.g., set error state to display an error message to the user.
      setError('Failed to submit the form. Please try again later.');
    }
  };

  // Function to update form data when input fields change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };
/*--------------------------------------------------*/

return (

    <>
      {props.from != 'view_result' && <Header></Header>}
      {!tableView &&
        <><div className="containers"> <div className="containers search">
          <ul>
            <li><div className="searchForm">
              <span><PersonSearchRoundedIcon /></span>

              <span>
                <input placeholder="Search for Contact" type="text" />
              </span>
            </div></li>
            <li onClick={handleResultClick}>
              {count === 0 ? "0 Result" : `${count} Result${count !== 1 ? "s" : ""}`}
            </li>
            <li onClick={handleClearAll}>Clear All</li>
            <li><div className="searchForm">

              <span>
                <input placeholder="Find Filter" type="text" />
              </span>
            </div></li>
            <li><div className="view">

              <span>
                <Button variant="view"
                  onClick={() => clickViewBtn()} >View Result</Button>
              </span>
            </div></li>
          </ul>
        </div><div className="top-menu">
            <ul>
              <li onClick={() => selectedMenuClick('Contact Level')}
                className={selectedMenu === 'Contact Level' ? 'selected' : ''}>Contact Level</li>
              <li onClick={() => selectedMenuClick('Location')}
                className={selectedMenu === 'Location' ? 'selected' : ''}>Location</li>
              <li onClick={() => selectedMenuClick('Company Size')}
                className={selectedMenu === 'Company Size' ? 'selected' : ''}>Company Size</li>
              <li onClick={() => selectedMenuClick('Industry')}
                className={selectedMenu === 'Industry' ? 'selected' : ''}>Industry</li>
              <li onClick={() => selectedMenuClick('Additional')}
                className={selectedMenu === 'Additional' ? 'selected' : ''}>Additional</li>
            </ul>
          </div><div className="contant">
            {(selectedMenu === 'Contact Level' || selectedMenu === 'showAll') && <Box sx={{ width: '100%' }}>
              <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                <Grid item xs={12}>
                  <div className="maintitle">Contact</div>
                </Grid>
                <Grid item xs={6}>
                  <div className="subtitle">
                    <label>Contact Level</label>
                    <FormControlLabel
                      control={<Switch checked={isContactChecked} onChange={(e)=>handleExcludeChange('contact',e)} />}
                      label="Exclude" />
                    <Controller
                      control={control}
                      name='contact.contactlevel'
                      render={({ field: { onChange, value, ref } }) => (
                        
                        <><Autocomplete
                          multiple
                          disableClearable
                          filterSelectedOptions
                          disablePortal
                          //  id="combo-box-demo"
                          options={contactOptionsData}
                          sx={{ width: 300 }}
                          getOptionLabel={(option) => option.label}
                          renderInput={(params) => (<TextField {...params}
                            label="Contact Level"
                            inputRef={ref}
                          />)}
                          onChange={(event, item) => {
                            setDefaultContact(setLabelForm(item.map((val) => val.label))); 
                            onChange(item.map((val) => val.label));
                            setResult();
                          }}
                          ref={refContactLevel}                          
                          value={defaultContact}
                        />̥
                        </>
                      )}

                    />

                  </div>



                </Grid>
                <Grid item xs={6}>
                  <div className="subtitle">

                    <label>Title</label>
                    <FormControlLabel
                      control={<Switch checked={isTitleChecked} onChange={(e)=>handleExcludeChange('title',e)} />}
                      label="Exclude" />
                    <div className="subinput">
                      
                    <Controller
                      name="contact.contacttitle"
                      control={control}
                      defaultValue=''
                      render={({ field }) => (
                        <input
                          type="text"
                          {...field}
                          onChange={(e) => {
                            field.onChange(e);
                            handleTitleKeyPress(e);
                          }}
                          value={getValues("contact.contacttitle")}
                          placeholder="Title"
                        />
                      )}
                    />
                      {/* <input type="text" value={getValues("contact.contacttitle")} onChange={(e) => handleTitleKeyPress(e)} placeholder="Title" /> */}
                    </div>
                  </div>
                </Grid>

              </Grid>
            </Box>
            }

            {(selectedMenu === 'Location' || selectedMenu === 'showAll') && <Box sx={{ width: '100%' }}>
              <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                <Grid item xs={12}>
                  <div className="maintitle">locations</div>
                </Grid>
                <Grid item xs={6}>
                  <div className="subtitle">

                    <label>Country</label>
                    <FormControlLabel
                      control={<Switch checked={isCountryChecked} onChange={(e)=>handleExcludeChange('country',e)} />}
                      label="Exclude" />
                    <Controller
                      control={control}
                      name='country.companycountry'
                      render={({ field: { onChange, value, ref } }) => (
                        <> <Autocomplete
                          multiple
                          disableClearable
                          filterSelectedOptions
                          disablePortal
                          //  id="combo-box-demo"
                          options={countriesOptionsData}
                          sx={{ width: 300 }}
                          getOptionLabel={(option) => option.label}
                          renderInput={(params) => (<TextField {...params}
                            label="Country"
                            inputRef={ref}

                          />)}

                          onChange={(event, item) => {
                            setDefaultCountry(setLabelForm(item.map((val) => val.label)));
                            onChange(item.map(val => val.label));
                            setResult();
                          }}
                          value={defaultCountry}
                        />̥
                        </>
                      )}

                    />
                  </div>
                </Grid>
                <Grid item xs={6}>
                  <div className="subtitle">

                    <label>State</label>
                    <FormControlLabel
                      control={<Switch checked={isStateChecked} onChange={(e)=>handleExcludeChange('state',e)} />}
                      label="Exclude" />
                    <Controller
                      control={control}
                      name='country.companystate'
                      render={({ field: { onChange, value, ref } }) => (
                        <> <Autocomplete

                          multiple
                          disableClearable
                          filterSelectedOptions
                          disablePortal
                          //  id="combo-box-demo"
                          options={statesOptionsData}
                          sx={{ width: 300 }}
                          getOptionLabel={(option) => option.label}
                          renderInput={(params) => (<TextField {...params}
                            label="Company State"
                            inputRef={ref}
                          />)}

                          onChange={(event, item) => {
                            setDefaultState(setLabelForm(item.map((val) => val.label)));
                            onChange(item.map(val => val.label));
                            setResult();
                          }}
                          value={defaultState}
                        />̥
                        </>
                      )}

                    />
                  </div>
                </Grid>

                <Grid item xs={6}>
                  <div className="subtitle">

                    <label>City</label>
                    <FormControlLabel
                      control={<Switch checked={isCityChecked} onChange={(e)=>handleExcludeChange('city',e)} />}
                      label="Exclude" />
                    <Controller
                      control={control}
                      name='country.companycity'
                      render={({ field: { onChange, value, ref } }) => (
                        <> <Autocomplete

                          multiple
                          disableClearable
                          filterSelectedOptions
                          disablePortal
                          //  id="combo-box-demo"
                          options={cityOptionsData}
                          sx={{ width: 300 }}
                          getOptionLabel={(option) => option.label}
                          renderInput={(params) => (<TextField {...params}
                            label="Company City"
                            inputRef={ref}
                          />)}

                          onChange={(event, item) => {
                            setDefaultCity(setLabelForm(item.map((val) => val.label)));
                            onChange(item.map(val => val.label));
                            setResult();
                          }}
                          value={defaultCity}
                        />̥
                        </>
                      )}

                    /></div>
                </Grid>
                <Grid item xs={6}>
                  <div className="subtitle">

                    <label>Zip Code</label>
                    <FormControlLabel
                      control={<Switch checked={isZipChecked} onChange={(e)=>handleExcludeChange('zip',e)} />}
                      label="Exclude" />
                    <Controller
                      control={control}
                      name='country.companyzipcode'
                      render={({ field: { onChange, value, ref } }) => (
                        <> <Autocomplete

                          multiple
                          disableClearable
                          filterSelectedOptions
                          disablePortal
                          //  id="combo-box-demo"
                          options={zipcodeOptionsData}
                          sx={{ width: 300 }}
                          getOptionLabel={(option) => option.label}
                          renderInput={(params) => (<TextField {...params}
                            label="Company ZipCode"
                            inputRef={ref}
                          />)}

                          onChange={(event, item) => {
                            setDefaultZip(setLabelForm(item.map((val) => val.label)));
                            onChange(item.map(val => val.label));
                            setResult();
                          }}
                          value={defaultZip}
                        />̥
                        </>
                      )}

                    /></div>
                </Grid>

                <Grid item xs={6}>
                  <div className="subtitle">

                    <label>Metro Area</label>
                    <FormControlLabel
                      control={<Switch checked={isMetroChecked} onChange={(e)=>handleExcludeChange('metro',e)} />}
                      label="Exclude" />
                    <Controller
                      control={control}
                      name='country.metroarea'
                      render={({ field: { onChange, value, ref } }) => (
                        <> <Autocomplete

                          multiple
                          disableClearable
                          filterSelectedOptions
                          disablePortal
                          //  id="combo-box-demo"
                          options={METROAREA}
                          sx={{ width: 300 }}
                          getOptionLabel={(option) => option.label}
                          renderInput={(params) => (<TextField {...params}
                            label="Metro Area"
                            inputRef={ref}
                          />)}

                          onChange={(event, item) => {
                            setDefaultMetro(setLabelForm(item.map((val) => val.label)));
                            onChange(item.map(val => val.label));
                            setResult();
                          }}
                          value={defaultMetro}
                        />̥
                        </>
                      )}

                    /></div>
                </Grid>
                <Grid item xs={6}>
                  <div className="subtitle">

                    <label>County</label>
                    <FormControlLabel
                      control={<Switch checked={isCompanyCountryChecked} onChange={(e)=>handleExcludeChange('companycountry',e)}/>}
                      label="Exclude" />
                    <Controller
                      control={control}
                      name='country.companycounty'
                      render={({ field: { onChange, value, ref } }) => (
                        <> <Autocomplete

                          multiple
                          disableClearable
                          filterSelectedOptions
                          disablePortal
                          //  id="combo-box-demo"
                          options={countryOptionsData}
                          sx={{ width: 300 }}
                          getOptionLabel={(option) => option.label}
                          renderInput={(params) => (<TextField {...params}
                            label="Company County"
                            inputRef={ref}
                          />)}

                          onChange={(event, item) => {
                            setDefaultCounty(setLabelForm(item.map((val) => val.label)));
                            onChange(item.map(val => val.label));
                            setResult();
                          }}
                          value={defaultCounty}
                        />̥
                        </>
                      )}

                    /></div>
                </Grid>

              </Grid>
            </Box>}


            {(selectedMenu === 'Company Size' || selectedMenu === 'showAll') && <Box sx={{ width: '100%' }}>
              <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                <Grid item xs={12}>
                  <div className="maintitle">Company Size</div>
                </Grid>
                <Grid item xs={6}>
                  <div className="subtitle">

                    <label>Employee Size From </label>
                    
                    <FormControlLabel
                      control={<Switch checked={isEsizeFromChecked} onChange={(e)=>handleExcludeChange('employeesizefrom',e)} />}
                      label="Exclude" />
                    <div className="subinput">
                    <Controller
                      name="company.CompanyemployeesFrom"
                      control={control}
                      defaultValue=''
                      render={({ field }) => (
                        <input
                          type="text"
                          {...field}
                          onChange={(e) => {
                            field.onChange(e);
                            setValue('company.CompanyemployeesFrom', e.target.value);
                            setResult();
                          }}
                          value={getValues("company.CompanyemployeesFrom")}
                          placeholder="Company Employees From"
                        />
                      )}
                    />
                      {/* <input type="text"  {...register("company.Companyemployees")} placeholder="Company Employees From" /> */}
                    </div>
                  </div>
                </Grid>
                <Grid item xs={6}>
                  <div className="subtitle">

                    <label>Employee Size To </label>
                    <FormControlLabel
                      control={<Switch checked={isEsizeToChecked} onChange={(e)=>handleExcludeChange('employeesizeto',e)} />}
                      label="Exclude" />
                    <div className="subinput">
                    <Controller
                      name="company.CompanyemployeesTo"
                      control={control}
                      defaultValue=''
                      render={({ field }) => (
                        <input
                          type="text"
                          {...field}
                          onChange={(e) => {
                            field.onChange(e);
                            setValue('company.CompanyemployeesTo', e.target.value);
                            setResult();
                          }}
                          value={getValues("company.CompanyemployeesTo")}
                          placeholder="Company Employees To"
                        />
                      )}
                    />
                      {/* <input type="text" {...register("company.Companyemployees")} placeholder="Company Employees To" /> */}
                      </div>
                  </div>
                </Grid>

                <Grid item xs={6}>
                  <div className="subtitle">

                    <label>Revenue Size From</label>
                    <FormControlLabel
                      control={<Switch checked={isRsizeFromChecked} onChange={(e)=>handleExcludeChange('revenuesizefrom',e)} />}
                      label="Exclude" />
                    <div className="subinput">
                    <Controller
                      name="company.CompanyRevenueFrom"
                      control={control}
                      defaultValue=''
                      render={({ field }) => (
                        <input
                          type="text"
                          {...field}
                          onChange={(e) => {
                            field.onChange(e);
                            setValue('company.CompanyRevenueFrom', e.target.value);
                            setResult();
                          }}
                          value={getValues("company.CompanyRevenueFrom")}
                          placeholder="Company Revenue From"
                        />
                      )}
                    />
                      {/* <input type="text" {...register("company.Companyrevenue")} placeholder="Company Revenue From " /> */}
                      </div>
                  </div>
                </Grid>
                <Grid item xs={6}>
                  <div className="subtitle">

                    <label>Revenue Size to</label>
                    <FormControlLabel
                      control={<Switch checked={isRsizeToChecked} onChange={(e)=>handleExcludeChange('revenuesizeto',e)} />}
                      label="Exclude" />
                    <div className="subinput">
                    <Controller
                      name="company.CompanyRevenueTo"
                      control={control}
                      defaultValue=''
                      render={({ field }) => (
                        <input
                          type="text"
                          {...field}
                          onChange={(e) => {
                            field.onChange(e);
                            setValue('company.CompanyRevenueTo', e.target.value);
                            setResult();
                          }}
                          value={getValues("company.CompanyRevenueTo")}
                          placeholder="Company Revenue To"
                        />
                      )}
                    />
                      {/* CompanyRevenueFrom <input type="text" {...register("company.Companyrevenue")} placeholder="Company Revenue To" /> */}
                      </div>
                  </div></Grid>

              </Grid>
            </Box>}

            {(selectedMenu === 'Industry' || selectedMenu === 'showAll') && <Box sx={{ width: '100%' }}>
              <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                <Grid item xs={12}>
                  <div className="maintitle">Industry</div>
                </Grid>
                <Grid item xs={6}>
                  <div className="subtitle">

                    <label>SIC Code and Industry</label>
                    <FormControlLabel
                      control={<Switch checked={isSICChecked} onChange={(e)=>handleExcludeChange('sic',e)} />}
                      label="Exclude" />
                    <Controller
                      control={control}
                      name='industry.siccode'
                      render={({ field: { onChange, value, ref } }) => (
                        <> <Autocomplete

                          multiple
                          disableClearable
                          filterSelectedOptions
                          disablePortal
                          //  id="combo-box-demo"
                          options={SICCODE}
                          sx={{ width: 300 }}
                          getOptionLabel={(option) => option.label}
                          renderInput={(params) => (<TextField {...params}
                            label="Sic Code"
                            inputRef={ref}
                          />)}

                          onChange={(event, item) => {
                            setDefaultSIC(setLabelForm(item.map((val) => val.label)));
                            onChange(item.map(val => val.label));
                            setResult();
                          }}
                          value={defaultSIC}
                        />̥
                        </>
                      )}

                    /></div>
                </Grid>
                <Grid item xs={6}>
                  <div className="subtitle">

                    <label>NAICS Code</label>
                    <FormControlLabel
                      control={<Switch checked={isNAICSChecked} onChange={(e)=>handleExcludeChange('naics',e)} />}
                      label="Exclude" />
                    <Controller
                      control={control}
                      name='industry.naicscode'
                      render={({ field: { onChange, value, ref } }) => (
                        <> <Autocomplete

                          multiple
                          disableClearable
                          filterSelectedOptions
                          disablePortal
                          //  id="combo-box-demo"
                          options={NAICSCODE}
                          sx={{ width: 300 }}
                          getOptionLabel={(option) => option.label}
                          renderInput={(params) => (<TextField {...params}
                            label="NAICS Code"
                            inputRef={ref}
                          />)}

                          onChange={(event, item) => {
                            setDefaultNAICS(setLabelForm(item.map((val) => val.label)));
                            onChange(item.map(val => val.label));
                            setResult();
                          }}
                          value={defaultNAICS}
                        />̥
                        </>
                      )}

                    />

                  </div>
                </Grid>

              </Grid>
            </Box>}

            {(selectedMenu === 'Additional' || selectedMenu === 'showAll') && <Box sx={{ width: '100%' }}>
              <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                <Grid item xs={12}>
                  <div className="maintitle">Additional</div>
                </Grid>
                <Grid item xs={6}>
                  <div className="subtitle">

                    <label>Company Search</label>
                    <FormControlLabel
                      control={<Switch checked={isCompanyChecked} onChange={(e)=>handleExcludeChange('companysearch',e)} />}
                      label="Exclude" />
                    <div className="subinput">
                    <Controller
                      name="additional.Company_search"
                      control={control}
                      defaultValue=''
                      render={({ field }) => (
                        <input
                          type="text"
                          {...field}
                          onChange={(e) => {
                            field.onChange(e);
                            setValue('additional.Company_search', e.target.value);
                            setResult();
                          }}
                          value={getValues("additional.Company_search")}
                          placeholder="Company Search"
                        />
                      )}
                    />
                      {/* <input type="text" {...register("company.Company_search")} placeholder="Company Search" /> */}
                    </div></div>
                </Grid>
                <Grid item xs={6}>
                  <div className="subtitle">

                    <label>Website Search</label>
                    <FormControlLabel
                      control={<Switch checked={isWebsiteChecked} onChange={(e)=>handleExcludeChange('websitesearch',e)} />}
                      label="Exclude" />
                    <Controller
                      control={control}
                      name='additional.website_search'
                      render={({ field: { onChange, value, ref } }) => (
                        <> <Autocomplete

                          multiple
                          disableClearable
                          filterSelectedOptions
                          disablePortal
                          //  id="combo-box-demo"
                          options={WEBSITESEARCH}
                          sx={{ width: 300 }}
                          getOptionLabel={(option) => option.label}
                          renderInput={(params) => (<TextField {...params}
                            label="Website Search"
                            inputRef={ref}
                          />)}

                          onChange={(event, item) => {
                            setDefaultWebSiteSearch(setLabelForm(item.map((val) => val.label)));
                            onChange(item.map(val => val.label));
                            setResult();
                          }}
                          value={defaultWebSiteSearch}
                        />̥
                        </>
                      )}

                    /></div>
                </Grid>

              </Grid>
            </Box>}

          </div></div></>}

      {tableView && <Result Rows={rows} control={control} />}

    </>
  )
}

export default SearchBuild;